<?php

	require'functions.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>DDBank Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
	*{
		margin:0;
		padding:0;
	}
	.header{
		width:100%;
		height:50px;
		color:#ffffff;
	}
	.header h5{
		z-index:0;
		position:absolute;
		top:0;
		left:0;
		font-size:23px;
		letter-spacing:2px;
		font-family:Times New Romans;
		padding-left:50px;
		padding-top:10px;
	}
	.card{
		border:0px;
		border-radius:0px;
	}
	.menu{
		display:none;
		position:absolute;
		top:50px;
		left:0;
		width:250px;
		z-index:9999;
		color:#ffffff;
	}
	.menu .list-group{
		border-radius:0px;
		border:0px;
	}
	.menu .list-group .list-group-item{
		border:0px;
		text-align:right;
		letter-spacing:2px;
	}
	a{
		text-decoration:none;
	}
	a:hover{
		text-decoration:none;
	}
</style>

</head>
<body>

<div class="header shadow-sm bg-primary">
	<i onclick="openmenu()" class="fa fa-bars pt-3 pl-4"> <h5>DDBank</h5></i>
	<i class="fa fa-sign-out pull-right pt-3 pr-4"></i>
</div>
  
<div class="menu shadow-sm">
	
	<ul class="list-group shadow-sm">
		<a href="index.php"><li class="list-group-item shadow-sm text-primary"><i class="fa fa-dashboard pull-left"></i> Dashboard</li></a>
		<a href="customers.php"><li class="list-group-item shadow-sm text-primary"><i class="fa fa-users pull-left"></i> Customers</li></a>
		<a href="transfers.php"><li class="list-group-item shadow-sm text-primary"><i class="fa fa-recycle pull-left"></i> Bank Transfers</li></a>
	</ul>
	
</div>  
  
<div class="container">
	
	<h4 class="pt-4 pb-4 text-center">Dashboard</h4>
	
<?php

function transferscount(){	
$conn = conn();

$sql = "SELECT * FROM transfers";
$result = mysqli_query($conn, $sql);

return mysqli_num_rows($result);

}

function customerscount(){	
$conn = conn();

$sql = "SELECT * FROM customers";
$result = mysqli_query($conn, $sql);

return mysqli_num_rows($result);

}

?>	
	
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-3 col-6">
			<a href="customers.php" class="card card-body shadow-sm">
				<h1 class="text-center text-primary"><i class="fa fa-users"></i> <?php echo customerscount(); ?></h1>
				<small class="text-muted text-center">Customers</small>
			</a>
		</div>
		<div class="col-md-3 col-6">
			<a href="transfers.php" class="card card-body shadow-sm">
				<h1 class="text-center text-primary"><i class="fa fa-recycle"></i> <?php echo transferscount();?></h1>
				<small class="text-muted text-center">Bank Transfers</small>
			</a>
		</div>
		<div class="col-md-3 col-6"></div>
	</div>

</div>

<script>
	function openmenu(){
		$(".menu").toggle(200);
	}
</script>

</body>
</html>
