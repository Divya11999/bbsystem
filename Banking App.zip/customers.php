<?php 

	require 'functions.php';
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>DDBank Customers</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
	*{
		margin:0;
		padding:0;
	}
	.header{
		width:100%;
		height:50px;
		color:#ffffff;
	}
	.header h5{
		z-index:0;
		position:absolute;
		top:0;
		left:0;
		font-size:23px;
		letter-spacing:2px;
		font-family:Times New Romans;
		padding-left:50px;
		padding-top:10px;
	}
	.card{
		border:0px;
		border-radius:0px;
	}
	.menu{
		display:none;
		position:absolute;
		top:50px;
		left:0;
		width:250px;
		z-index:9999;
		color:#ffffff;
	}
	.menu .list-group{
		border-radius:0px;
		border:0px;
	}
	.menu .list-group .list-group-item{
		border:0px;
		text-align:right;
		letter-spacing:2px;
	}
	a{
		text-decoration:none;
	}
	a:hover{
		text-decoration:none;
	}
</style>

</head>
<body>

<div class="header shadow-sm bg-primary">
	<i onclick="openmenu()" class="fa fa-bars pt-3 pl-4"> <h5>DDBank</h5></i>
	<i class="fa fa-sign-out pull-right pt-3 pr-4"></i>
</div>
  
<div class="menu shadow-sm">
	
	<ul class="list-group shadow-sm">
		<a href="index.php"><li class="list-group-item shadow-sm text-primary"><i class="fa fa-dashboard pull-left"></i> Dashboard</li></a>
		<a href="customers.php"><li class="list-group-item shadow-sm text-primary"><i class="fa fa-users pull-left"></i> Customers</li></a>
		<a href="transfers.php"><li class="list-group-item shadow-sm text-primary"><i class="fa fa-recycle pull-left"></i> Bank Transfers</li></a>
	</ul>
	
</div>  
  
<div class="container">
	
	<h4 class="pt-4 pb-4 text-center">Customers</h4>
	
  <div class="input-group mb-3 shadow-sm">
    <input type="text" class="form-control" id="myInput" placeholder="Search Customer By Account Number / By Name etc..">
    <div class="input-group-append">
      <span class="btn btn-primary"><i class="fa fa-search"></i></span>
    </div>
  </div>
	
<div class="table-responsive">
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Account Number</th>
        <th>Customer Name</th>
        <th>Customer Contact</th>
		<th>Customer Email ID</th>
		<th>Current Balance</th>
		<th>Actions</th>
      </tr>
    </thead>
	<tbody>
	
	<?php
	
			$conn = conn();
			$sql = "SELECT * FROM customers";
			$result = mysqli_query($conn, $sql);
			
			if (mysqli_num_rows($result) > 0) {
			// output data of each row
				while($row = mysqli_fetch_assoc($result)) {
					
	?>

					<tr>
						<td>DDB00<?php echo $row["id"];?></td>
						<td><?php echo $row["customername"];?></td>
						<td>+<?php echo $row["customercontact"];?></td>
						<td><?php echo $row["customeremail"];?></td>
						<td><i class="fa fa-rupee"></i> <?php echo $row["currentbalance"];?>/-</td>
						<td><a data-cname="<?php echo $row["customername"];?>" data-ccontact="<?php echo $row["customercontact"];?>" data-cemail="<?php echo $row["customeremail"];?>" data-cb="<?php echo $row["currentbalance"];?>" id="view" class="btn btn-sm btn-primary"><i class="fa fa-eye"></i> View</a> <a class="btn btn-sm btn-success" id="transfers" data-crb="<?php echo $row["currentbalance"];?>" data-accountid="<?php echo $row["id"];?>"><i class="fa fa-recycle"></i> Transfer</a></td>
					</tr>

	<?php	
		
				}
			} else {
				echo "0 results";
			}	
		
	?>	

	</tbody>
	
  </table>
</div>

</div>



	  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Customer Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
	

					<p><b>Name :</b></p>
					<p id="cname"></p>
					<p><b>Contact :</b></p>
					<p id="ccontact"></p>
					<p><b>Email ID :</b></p>
					<p id="cemail"></p>
					<p><b>Current Balance :</b></p>
					<p id="cb"></p>
	
        </div>
        
      </div>
    </div>
  </div>
  
  	  <!-- The Modal -->
  <div class="modal fade" id="mytransferModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Internal Bank Transfer</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
	
<form action="customers.php" method="POST">
	
<div class="form-group">
  <label for="sel1">Select From Account Number:</label>
  <select class="form-control" disabled required id="fromid">

  </select>
</div>

<div class="form-group">
  <label for="usr">Current Balance:</label>
  <input type="text" class="form-control" required disabled id="fromusercb">
</div>

<div class="form-group" style="display:none;">
  <label for="usr">Current from customer:</label>
  <input type="text" class="form-control" required name="fromid" id="tfromid">
</div>

<div class="form-group" style="display:none;">
  <label for="usr">Current Balance:</label>
  <input type="text" class="form-control" required name="fromusercb" id="tfromusercb">
</div>

<div class="form-group">
  <label for="sel1">Select Beneficiary Account Number:</label>
  <select class="form-control" name="toid" required id="toid">

	<?php
	
			$conn = conn();
			$sqlo = "SELECT * FROM customers";
			$resulto = mysqli_query($conn, $sqlo);
			
			if (mysqli_num_rows($resulto) > 0) {
			// output data of each row
				while($rowo = mysqli_fetch_assoc($resulto)) {
					
	?>
				
				<option value="<?php echo $rowo["id"]?>">DDB00<?php echo $rowo["id"]?></option>
				
	<?php 
				}
			}
    ?>			


  </select>
</div>

<div class="form-group">
  <label for="usr">Enter Amount:</label>
  <input type="text" placeholder="Enter Amount Not a More then Current Balance" required class="form-control" name="tamount">
</div>

  <button type="submit" class="btn btn-success" name="itransfer">Transfer Balance</button>
</form>
	
        </div>
        
      </div>
    </div>
  </div>
	

<?php

	if(isset($_POST["itransfer"])){
		
		$conn = conn();
		
		$tbalance = $_POST["tamount"];
		$fromid = $_POST["fromid"];
		$fromusercb = $_POST["fromusercb"]-$tbalance;
		$toid = $_POST["toid"];
		$tousercb = getcustomercurrentbalance($conn,$toid)+$tbalance;
		
		if($fromid!=$toid){
		
		$resone = updatecustomercurrentbalance($conn,$fromid,$fromusercb);
		
		if($resone==1){
			
			$restwo = updatecustomercurrentbalance($conn,$toid,$tousercb);
			
			if($restwo==1){
				
				$resthree = createtransfer($conn,$fromid,$toid,$tbalance);
				
				if($resthree==1){
					echo'<script>alert("Internal Bank Transfer Successfull !");window.location.assign("customers.php");</script>';
				}
				
			}
			
		}else{
			echo'<script>alert("Server Down Please Try After Sometimes !");window.location.assign("customers.php");</script>';
		}
		
		}else{
			echo'<script>alert("Select Valid Beneficiary Account Number !");window.location.assign("customers.php");</script>';
		}
		
		
	}
	
	function getcustomercurrentbalance($conn,$accountid){
		
			$sqlcb = "SELECT * FROM customers WHERE id='$accountid'";
			$resultcb = mysqli_query($conn, $sqlcb);
			
			if (mysqli_num_rows($resultcb) > 0) {
			// output data of each row
				$rowcb = mysqli_fetch_assoc($resultcb);
				return $rowcb["currentbalance"];
			}else{
				return 0;
			}
		
	}

	function updatecustomercurrentbalance($conn,$accountid,$cb){
	
			$sqlcb = "UPDATE customers SET currentbalance='$cb' WHERE id='$accountid'";
			$resultcb = mysqli_query($conn, $sqlcb);
			
			if ($resultcb) {
				return 1;
			}else{
				return 0;
			}
			
	}
	
	function createtransfer($conn,$fromid,$toid,$tbalance){
		
		$transferdate = date("d-m-Y");
		
		$sql = "INSERT INTO transfers (fromid, toid, amount, date) VALUES ('$fromid', '$toid', '$tbalance', '$transferdate')";
		
		if (mysqli_query($conn, $sql)) {
			return 1;
		} else {
			return 0;
		}
		
	}

?>	
	
  

<script>

	function openmenu(){
		$(".menu").toggle(200);
	}

  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("tbody tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
  
	
	$("tbody tr td").on("click","#view",function(){
		var cname = $(this).attr("data-cname");
		var ccontact = $(this).attr("data-ccontact");
		var cemail = $(this).attr("data-cemail");
		var cb = $(this).attr("data-cb");		
	
		$("#cname").text(cname);
		$("#ccontact").text(ccontact);	
		$("#cemail").text(cemail);
		$("#cb").text(cb);		
		
		$("#myModal").modal("show");
	});
	
	$("tbody tr td").on("click","#transfers",function(){
		var cb = $(this).attr("data-crb");
		var accountid = $(this).attr("data-accountid");
		var htmlvar = '<option data="'+cb+'">DDB00'+accountid+'</option>';
		$("#fromid").html(htmlvar);
		$("#fromusercb").val(cb);
		$("#tfromid").val(accountid);
		$("#tfromusercb").val(cb);
		$("#mytransferModal").modal("show");
	});
		
	
</script>

</body>
</html>
